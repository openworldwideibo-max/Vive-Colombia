import { LoaderCircle } from "lucide-react";
import { Navigate, Outlet } from "react-router";
import { useAuth } from "../context/AuthContext";

export default function GuestRoute() {
  const { isAuthenticated, isLoading } = useAuth();

  if (isLoading) {
    return (
      <section className="flex min-h-[70vh] items-center justify-center">
        <LoaderCircle className="h-10 w-10 animate-spin text-blue-600" />
      </section>
    );
  }

  if (isAuthenticated) {
    return <Navigate to="/mi-cuenta" replace />;
  }

  return <Outlet />;
}
