import { LoaderCircle } from "lucide-react";
import { Navigate, Outlet, useLocation } from "react-router";
import { useAuth } from "../context/AuthContext";

export default function ProtectedRoute() {
  const { isAuthenticated, isLoading } = useAuth();
  const location = useLocation();

  if (isLoading) {
    return (
      <section className="flex min-h-[70vh] items-center justify-center">
        <LoaderCircle className="h-10 w-10 animate-spin text-blue-600" />
      </section>
    );
  }

  if (!isAuthenticated) {
    return (
      <Navigate
        to="/iniciar-sesion"
        replace
        state={{ from: location.pathname }}
      />
    );
  }

  return <Outlet />;
}
