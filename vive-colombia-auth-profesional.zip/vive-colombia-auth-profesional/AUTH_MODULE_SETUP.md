# VIVE+COLOMBIA — módulo de autenticación

## Incluye

- Registro con correo y contraseña.
- Inicio de sesión con correo y Google.
- Perfil automático en `users/{uid}` de Firestore.
- Rol inicial seguro: `tourist`.
- Ruta protegida `/mi-cuenta`.
- Redirección de usuarios autenticados fuera de `/iniciar-sesion` y `/registro`.
- Navbar conectado al estado de la sesión.
- Reglas iniciales de seguridad para la colección `users`.

## Paso obligatorio en Firebase

En Firebase Console abre:

`Firestore Database → Reglas`

Reemplaza las reglas actuales por el contenido del archivo `firestore.rules` y presiona **Publicar**.

Sin este paso, Firestore en modo producción rechazará la creación del perfil del usuario.

## Verificación

1. Confirma que `.env.local` conserva los valores reales de Firebase.
2. Ejecuta `npm install`.
3. Ejecuta `npm run build`.
4. Ejecuta `npm run dev -- --host 0.0.0.0`.
5. Prueba `/registro` y luego revisa:
   - Firebase Authentication → Usuarios.
   - Firestore Database → Datos → users.

## Seguridad

Los usuarios públicos siempre se crean con rol `tourist`. Las reglas impiden que el usuario cambie su propio rol o active/desactive su cuenta desde el navegador.
